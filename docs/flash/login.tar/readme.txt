Flash Animations from www.flashiness.com

The zip file contains this readme.txt file and a .html file and a .swf file for each animation.  The .html file is a sample web page which displays the Flash animation in the .swf file.

To test the animations, unzip both the .html file and the .swf file to the same folder or directory on your computer.  Load the .html file in your browser and it will display the animation.

To include the animation in your own web pages:

1. Cut and paste the html code within the body section of the html (starting with the <object tag and ending with the </object> tag) from the supplied html file into your own web page.  Note that nothing will display until you complete step 2 below.

2. Upload both your web page and the .swf file to your web server.  You must put both in the same directory or folder on your web server.

That's it!

Problems? - Make sure the .swf file is in the same directory on the server as the web page.

All contents are copyright Flashiness.com

You may incorporate the animations in your own web pages provided the .swf files are not modified in any way.

You may distribute the zip file in its entirety provided it is not modified in any way.